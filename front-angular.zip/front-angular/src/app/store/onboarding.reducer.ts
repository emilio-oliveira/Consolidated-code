import { createReducer, on } from '@ngrx/store';
import { Onboarding } from './onboard.model';
import { clearOnboarding, setOnboarding } from './onboarding.actions';

export const intialOnboardingEntries: Onboarding = {
  clientEmail: '',
  taskIdEdit: '',
};

export const onboardingReducer = createReducer(
  intialOnboardingEntries,

  on(clearOnboarding, (_) => intialOnboardingEntries),

  on(setOnboarding, (state, object) => {
    return { ...state, ...object };
  })
);
