export interface Onboarding {
  clientEmail: string;
  taskIdEdit: string;
}
