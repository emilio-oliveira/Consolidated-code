import { createAction, props } from '@ngrx/store';
import { Onboarding } from './onboard.model';

export const setOnboarding = createAction(
  'Set Onboarding',
  props<Onboarding>()
);
export const unsetOnboarding = createAction(
  'Unset Onboarding',
  props<Onboarding>()
);
export const clearOnboarding = createAction('Clear Onboarding');
