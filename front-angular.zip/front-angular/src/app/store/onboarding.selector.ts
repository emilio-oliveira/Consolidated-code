import { Onboarding } from './onboard.model';
import { createFeatureSelector, createSelector } from '@ngrx/store';

export const selectOnboarding = createSelector(
  createFeatureSelector('onboarding'),
  (state: Onboarding) => {
    return state;
  }
);
