import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

import { IconSetService } from '@coreui/icons-angular';
import { iconSubset } from './icons/icon-subset';
import { cilBarChart } from '@coreui/icons';

import { Title } from '@angular/platform-browser';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'body',
  template: `<router-outlet></router-outlet>`,
})
export class AppComponent implements OnInit {
  title = 'RBC';

  constructor(
    private router: Router,
    private titleService: Title,
    private iconSet: IconSetService
  ) {
    titleService.setTitle(this.title);
    iconSet.icons = { cilBarChart, ...iconSubset };
  }

  ngOnInit(): void {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
    });
  }
}
