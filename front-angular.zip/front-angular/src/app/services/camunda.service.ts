import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Observable, EMPTY, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import {
  CamundaPostStartProcessPayload,
  CamundaStartProcess,
  ProcessDefinition,
} from '../models/camunda.model';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT',
  }),
};

@Injectable({
  providedIn: 'root',
})
export class CamundaService {
  urlCamunda = '/engine-rest';
  urlBackend = 'http://localhost:8080/engine-rest';

  constructor(private http: HttpClient) {}

  public getProcesses(): Observable<any> {
    const url = `${this.urlBackend}/process-instance`;
    return this.http.get<ProcessDefinition[]>(url, httpOptions).pipe(
      map((obj) => obj),
      catchError(this.handleError)
    );
  }

  public getProcessesHistory(): Observable<any> {
    const url = `${this.urlBackend}/history/process-instance`;
    return this.http.get<ProcessDefinition[]>(url, httpOptions).pipe(
      map((obj) => obj),
      catchError(this.handleError)
    );
  }

  public getTaskListByBusinessKey(id: string) {
    const url = `${this.urlBackend}/task?processInstanceId=${id}`;
    return this.http.get<any[]>(url).pipe(
      map((obj: any[]) => <any[]>obj),
      catchError(this.handleError)
    );
  }

  public getTaskById(id: string) {
    const url = `${this.urlBackend}/task/${id}/variables?deserializeValues=false`;
    return this.http.get<any[]>(url).pipe(
      map((obj: any[]) => <any[]>obj),
      catchError(this.handleError)
    );
  }

  postStartProcess(
    payload: CamundaPostStartProcessPayload
  ): Observable<CamundaStartProcess> {
    const processId = 'onboarding-process'; //could change dynamically if necessary
    const url = `${this.urlBackend}/startProcess?processDefinitionId=${processId}`;
    return this.http.post<CamundaStartProcess>(url, payload).pipe(
      map((obj: CamundaStartProcess) => <CamundaStartProcess>obj),
      catchError(this.handleError)
    );
  }

  postUpdateTaskVariables(taskId: string, payload: any) {
    const url = `${this.urlBackend}/updateTaskVariables?taskId=${taskId}`;
    return this.http.post<CamundaStartProcess>(url, payload).pipe(
      map((obj: CamundaStartProcess) => <CamundaStartProcess>obj),
      catchError(this.handleError)
    );
  }

  getInstanceVariables(instanceId: string) {
    const url = `${this.urlBackend}/getInstanceVariables?processInstanceId=${instanceId}`;
    return this.http.get<Task[]>(url).pipe(
      map((obj: Task[]) => <Task[]>obj),
      catchError(this.handleError)
    );
  }

  postCompleteTask(taskId: string, payload: any) {
    const url = `${this.urlBackend}/task/${taskId}/complete`;
    return this.http.post<CamundaStartProcess>(url, payload).pipe(
      map((obj: CamundaStartProcess) => <CamundaStartProcess>obj),
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    return throwError(() => error);
  }
}
