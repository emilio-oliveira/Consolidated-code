import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DefaultLayoutComponent } from './containers';

import { RouterGuard } from './guard/router.guard';

const routes: Routes = [
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home',
    },
    children: [
      {
        path: 'task-list',
        loadChildren: () =>
          import('./views/task-list/task-list.module').then(
            (m) => m.TaskListModule
          ),
        canActivate: [RouterGuard],
      },
      // {
      //   path: 'dashboard',
      //   loadChildren: () =>
      //     import('./views/dashboard/dashboard.module').then(
      //       (m) => m.DashboardModule
      //     ),
      // },
    ],
  },
  {
    path: '404',
    loadChildren: () =>
      import('./views/pages/pages.module').then((m) => m.PagesModule),
    data: {
      title: 'Page 404',
    },
  },
  {
    path: '500',
    loadChildren: () =>
      import('./views/pages/pages.module').then((m) => m.PagesModule),
    data: {
      title: 'Page 500',
    },
  },
  {
    path: 'login',
    loadChildren: () =>
      import('./views/login/login.module').then((m) => m.LoginModule),
    data: {
      title: 'Login Page',
    },
  },
  {
    path: 'register',
    loadChildren: () =>
      import('./views/register/register.module').then((m) => m.RegisterModule),
    data: {
      title: 'Register Page',
    },
  },
  { path: '**', redirectTo: 'dashboard' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'top',
      anchorScrolling: 'enabled',
      initialNavigation: 'enabledBlocking',
      // relativeLinkResolution: 'legacy'
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
