import {Component, OnInit, ViewChild} from '@angular/core';
import {CamundaService} from '../../services/camunda.service';
import {ToasterComponent, ToasterPlacement} from '@coreui/angular';
import {AppToastComponent} from '../../shared/toaster/toast.component';
import {ProcessDefinition} from '../../models/camunda.model';
import {ActivatedRoute, Router} from '@angular/router';
import {Subscription} from 'rxjs';
import {Onboarding} from 'src/app/store/onboard.model';
import {Store} from '@ngrx/store';
import {selectOnboarding} from 'src/app/store/onboarding.selector';
import {FormBuilder, FormControl, Validators} from '@angular/forms';
import {setOnboarding} from 'src/app/store/onboarding.actions';
import {cilCheckCircle, cilFile, cilXCircle} from '@coreui/icons';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss'],
})
export class TaskListComponent implements OnInit {
  placement = ToasterPlacement.TopEnd;
  processos: ProcessDefinition[] = [];
  tasks: any[] = [];
  taskPayload: any;
  routerCheck: null | string = null;
  user: any
  @ViewChild(ToasterComponent) toaster!: ToasterComponent;

  constructor(
    private taskListService: CamundaService,
    private route: ActivatedRoute,
    private store: Store<Onboarding>,
    private camundaService: CamundaService,
    private fb: FormBuilder,
    private router: Router
  ) {
  }

  icons = {cilFile, cilXCircle, cilCheckCircle};
  modalVisible = false;
  modalCompleteVisible = false;

  storedVars: Onboarding = {
    clientEmail: '',
    taskIdEdit: '',
  };

  clientEmailSubscription: Subscription = this.store
    .select(selectOnboarding)
    .subscribe((store) => {
      this.storedVars = {
        clientEmail: store.clientEmail,
        taskIdEdit: store.taskIdEdit,
      };
    });

  mainForm = this.fb.group({
    status: new FormControl({value: '', disabled: false}, [Validators.required]),
    comments: new FormControl({value: '', disabled: false}),
  });

  dmnFieldConfig = {
    idLength: 0,
    idMask: '',
    idName: '',
    zipLength: 0,
    zipMask: '',
    zipType: '',
  };

  clientAttachmentFilename: any = '';

  selectedTask: any = null;
  selectedTaskID: any = null;

  ngOnInit(): void {
    this.getCamundaTasks();
    if (sessionStorage.getItem('USER')) {
      this.user = sessionStorage.getItem('USER')
      this.user = JSON.parse(this.user)
    }
  }

  getCamundaTasks(): void {
    this.camundaService
      .getProcessesHistory()
      .subscribe({
        next: (data: any) => {
          this.tasks = data.filter((item: any) => item.processDefinitionKey === 'wire-transfer-transaction');
          console.log("TASKS", this.tasks);
        },
        error: (e: any) => {
          this.errorMessage(e.message || e.error.error);
        },
      });
  }

  public setOnboarding(state: Onboarding) {
    this.store.dispatch(setOnboarding(state));
  }

  viewTask(id: any, processInstanceId: any) {
    this.setOnboarding({
      clientEmail: this.storedVars.clientEmail,
      taskIdEdit: id,
    });
    this.router.navigate([`task-list/${processInstanceId}`]);
  }

  onSubmit() {
    console.log("EITA", this.mainForm.value);
    const payload = {
      variables: {
        acceptTransaction: {
          value: this.mainForm.value.status === "true"
        }
      }
    }
    this.camundaService.postCompleteTask(this.selectedTaskID, payload).subscribe({
      next: () => {
        this.modalVisible = false;
      },
    })
  }

  onUpdate() {
    this.mainForm.markAllAsTouched();
    if (this.mainForm.valid) {
      const payload = {
        modifications: {
          clientDocument: {value: this.clientDocument?.value, type: 'String'},
          clientZip: {value: this.clientZip?.value, type: 'String'},
        },
      };

      this.camundaService
        .postUpdateTaskVariables(this.storedVars.taskIdEdit, payload)
        .subscribe({
          next: () => {
            this.modalVisible = false
          },
          error: (e: any) => {
            this.errorMessage(e.message || e.error.error);
          },
        });
    }
  }

  getStoredValue(variableName: string) {
    const filteredPayload = this.taskPayload.filter((el: any) =>
      el.name.includes(variableName)
    );
    return filteredPayload[0] ? filteredPayload[0].value : undefined;
  }


  errorMessage(message: string) {
  }

  addToast(options: any) {
    this.toaster.addToast(AppToastComponent, options);
  }

  get clientName() {
    return this.mainForm.get('clientName');
  }

  get clientCountry() {
    return this.mainForm.get('clientCountry');
  }

  get clientType() {
    return this.mainForm.get('clientType');
  }

  get clientEmail() {
    return this.mainForm.get('clientEmail');
  }

  get clientPhone() {
    return this.mainForm.get('clientPhone');
  }

  get clientDocument() {
    return this.mainForm.get('clientDocument');
  }

  get clientZip() {
    return this.mainForm.get('clientZip');
  }

  get rangeValue() {
    return this.mainForm.get('rangeValue');
  }

  openModal(item: any) {
    if (item.state === 'COMPLETED') {
      this.modalCompleteVisible = true
    } else if(this.user.clientEmail === 'Admin'){
      console.log("ITEM", item);
      this.taskListService.getTaskListByBusinessKey(item.id)
        .subscribe({
          next: (data) => {
            console.log("DATA", data)
            this.selectedTaskID = data[0]?.id
            this.taskListService.getTaskById(this.selectedTaskID)
              .subscribe({
                next: (task) => {
                  console.log("task", task)
                  this.selectedTask = task;
                  this.selectedTask.transaction = JSON.parse(this.selectedTask.transaction.value)
                  this.selectedTask.validations = JSON.parse(this.selectedTask.transactionValidationJson.value)
                  this.modalVisible = true
                },
                error: (e: any) => {
                  this.errorMessage(e.message || e.error.error);
                },
              });
          },
          error: (e: any) => {
            this.errorMessage(e.message || e.error.error);
          },
        });
    }
  }

  getValidations() {
    if (this.selectedTask) {
      return Object.keys(this.selectedTask?.validations).filter(
        key => this.selectedTask?.validations[key]
      );
    }
    return []
  }

  getValidationsName(name: string) {
    switch (name) {
      case 'accountBalance':
        return 'Account Balance Validation'
        break;
      case 'transferLimit':
        return 'Transfer Limit Validation'
        break;
      case 'cutOff':
        return 'Cut-Off Validation'
        break;
      default:
        return 'Holiday Validation'
    }
  }

}
