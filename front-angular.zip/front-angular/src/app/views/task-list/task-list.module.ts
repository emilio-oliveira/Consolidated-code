import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskListComponent } from './task-list.component';
import {
  GridModule,
  CardModule,
  ToastModule,
  FormModule,
  ListGroupModule,
  BadgeModule,
  TooltipModule, ModalModule, ButtonModule, TableModule, TableDirective,
} from '@coreui/angular';
import { TaskListRoutingModule } from './task-list-routing.module';
import { SharedComponentsModule } from '../../shared/shared-components.module';
import { CamundaService } from '../../services/camunda.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgxMaskModule, IConfig } from 'ngx-mask';

import { MomentModule } from 'ngx-moment';
import { IconModule } from '@coreui/icons-angular';

export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;

@NgModule({
  declarations: [TaskListComponent],
  imports: [
    CommonModule,
    GridModule,
    TaskListRoutingModule,
    CardModule,
    ToastModule,
    SharedComponentsModule,
    FormsModule,
    FormModule,
    ListGroupModule,
    ReactiveFormsModule,
    IconModule,
    NgxMaskModule.forRoot(),
    MomentModule,
    BadgeModule,
    TooltipModule,
    ModalModule,
    ButtonModule,
    TableModule,
  ],
  providers: [CamundaService],
})
export class TaskListModule {}
