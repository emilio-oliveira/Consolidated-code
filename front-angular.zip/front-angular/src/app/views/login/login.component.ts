import {Component, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {ToasterComponent, ToasterPlacement} from '@coreui/angular';
import {Store} from '@ngrx/store';
import {RouterService} from 'src/app/guard/guard.service';
import {CamundaService} from 'src/app/services/camunda.service';
import {AppToastComponent} from 'src/app/shared/toaster/toast.component';
import {Onboarding} from 'src/app/store/onboard.model';
import {setOnboarding} from 'src/app/store/onboarding.actions';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  mainForm = this.fb.group({
    clientEmail: new FormControl(null, [Validators.required,]),
    password: new FormControl(null, [Validators.required]),
  });

  @ViewChild(ToasterComponent) toaster!: ToasterComponent;

  constructor(
    private fb: FormBuilder,
    private store: Store,
    private camundaService: CamundaService,
    private router: Router,
    public routerService: RouterService
  ) {
  }

  onSubmit() {
    if (this.mainForm.valid) {
      this.router.navigate(['/'])
      sessionStorage.setItem("USER", JSON.stringify(this.mainForm.value));
    }
  }

  logIn() {
    this.routerService.login().subscribe(() => {
      if (this.routerService.isLoggedIn) {
        this.router.navigate(['/task-list'], {
          queryParamsHandling: 'preserve',
          preserveFragment: true,
        });
      }
    });
  }

  public setOnboarding(email: Onboarding) {
    this.store.dispatch(setOnboarding(email));
  }

  errorMessage(message: string, title: string = 'Communication Error') {
    this.addToast({
      title: title,
      delay: 5000,
      placement: ToasterPlacement.TopEnd,
      color: 'danger',
      autohide: true,
      message,
    });
  }

  addToast(options: any) {
    this.toaster.addToast(AppToastComponent, options);
  }

  get clientEmail() {
    return this.mainForm.get('clientEmail');
  }
}
