import { Component, OnInit, ViewChild } from '@angular/core';
import { CamundaService } from '../../services/camunda.service';
import { ToasterComponent, ToasterPlacement } from '@coreui/angular';
import { AppToastComponent } from '../../shared/toaster/toast.component';
import {
  ProcessDefinition,
  CamundaTask,
  CamundaPostStartProcessPayload,
  ClientAttachment,
} from '../../models/camunda.model';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Onboarding } from 'src/app/store/onboard.model';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { selectOnboarding } from 'src/app/store/onboarding.selector';
import Utils from '../../utils/fomatters.utils';

@Component({
  selector: 'app-onboarding',
  templateUrl: './onboarding.component.html',
  styleUrls: ['./onboarding.component.scss'],
})
export class OnboardingComponent implements OnInit {
  processos: ProcessDefinition[] = [];
  tasks: CamundaTask[] = [];
  formKey: string = '';

  mainForm = this.fb.group({
    clientCountry: new FormControl(null, [Validators.required]),
    clientType: new FormControl(null, [Validators.required]),
    clientName: new FormControl(null, [Validators.required]),
    clientEmail: new FormControl({ value: '', disabled: true }),
    clientPhone: new FormControl(null, [Validators.required]),
    clientPassword: new FormControl(null, [Validators.required]),
    clientAttachment: new FormControl(null, [Validators.required]),
  });

  clientAttachmentObject: any = {};

  @ViewChild(ToasterComponent) toaster!: ToasterComponent;

  clientEmailParam: string = '';

  clientEmailSubscription: Subscription = this.store
    .select(selectOnboarding)
    .subscribe((store) => {
      this.clientEmailParam = store.clientEmail;
    });

  constructor(
    private camundaService: CamundaService,
    private fb: FormBuilder,
    private router: Router,
    private store: Store<Onboarding>
  ) {}

  ngOnInit(): void {
    this.clientEmail?.setValue(this.clientEmailParam);
  }

  postCamundaStartProcess(payloadStartProcess: CamundaPostStartProcessPayload) {
    this.camundaService.postStartProcess(payloadStartProcess).subscribe({
      next: (data: any) => {
        this.router.navigate(['task-list']);
      },
      error: (e: any) => {
        this.errorMessage(e.message || e.error.error);
      },
    });
  }

  errorMessage(message: string) {
    this.addToast({
      title: 'Communication Error',
      delay: 5000,
      placement: ToasterPlacement.TopEnd,
      color: 'danger',
      autohide: true,
      message,
    });
  }

  addToast(options: any) {
    this.toaster.addToast(AppToastComponent, options);
  }

  onSubmit() {
    this.mainForm.markAllAsTouched();
    if (this.mainForm.valid) {
      this.postCamundaStartProcess(
        Utils.buildStartProcessPayload(
          this.mainForm,
          this.clientAttachmentObject
        )
      );
    }
  }

  handleInputFileChange(event: any) {
    this.clientAttachmentObject = this.clientAttachmentFormatter(event);
  }

  clientAttachmentFormatter = (event: any): void => {
    const reader = new FileReader();
    const files = event.target.files;
    if (files && files.length > 0) {
      const singleFile = files[0];
      reader.readAsDataURL(singleFile);
      reader.onload = () => {
        this.clientAttachmentObject = {
          value: reader.result ? reader.result?.toString().split(',')[1] : '',
          type: 'File',
          valueInfo: {
            filename: singleFile.name,
            mimeType: singleFile.type,
          },
        };
      };
    }
  };

  get clientName() {
    return this.mainForm.get('clientName');
  }

  get clientCountry() {
    return this.mainForm.get('clientCountry');
  }

  get clientType() {
    return this.mainForm.get('clientType');
  }

  get clientEmail() {
    return this.mainForm.get('clientEmail');
  }

  get clientPhone() {
    return this.mainForm.get('clientPhone');
  }

  get clientAttachment() {
    return this.mainForm.get('clientAttachment');
  }

  get clientPassword() {
    return this.mainForm.get('clientPassword');
  }
}
