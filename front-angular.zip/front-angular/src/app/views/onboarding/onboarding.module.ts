import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OnboardingComponent } from './onboarding.component';
import {
  GridModule,
  CardModule,
  ToastModule,
  FormModule,
  TooltipModule,
} from '@coreui/angular';
import { OnboardingRoutingModule } from './onbloarding-routing.module';
import { SharedComponentsModule } from '../../shared/shared-components.module';
import { CamundaService } from 'src/app/services/camunda.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [OnboardingComponent],
  imports: [
    CommonModule,
    GridModule,
    OnboardingRoutingModule,
    ReactiveFormsModule,
    CardModule,
    ToastModule,
    SharedComponentsModule,
    FormsModule,
    FormModule,
    TooltipModule,
  ],
  providers: [CamundaService],
})
export class OnboardingModule {}
