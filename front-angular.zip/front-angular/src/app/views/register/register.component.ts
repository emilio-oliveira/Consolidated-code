import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToasterComponent, ToasterPlacement } from '@coreui/angular';
import { CamundaPostStartProcessPayload } from 'src/app/models/camunda.model';
import { CamundaService } from 'src/app/services/camunda.service';
import { AppToastComponent } from '../../shared/toaster/toast.component';
import { setOnboarding } from 'src/app/store/onboarding.actions';
import { Store } from '@ngrx/store';
import { Onboarding } from 'src/app/store/onboard.model';
import { RouterService } from 'src/app/guard/guard.service';
import Utils from 'src/app/utils/fomatters.utils';

@Component({
  selector: 'app-onboard-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent {
  mainForm = this.fb.group({
    clientCountry: new FormControl(null, [Validators.required]),
    clientType: new FormControl(null, [Validators.required]),
    clientName: new FormControl(null, [Validators.required]),
    clientEmail: new FormControl(null, [Validators.required, Validators.email]),
    clientPhone: new FormControl(null, [Validators.required]),
    clientAttachment: new FormControl(null, [Validators.required]),
    clientPassword: new FormControl(null, [Validators.required]),
  });

  clientAttachmentObject: any = {};

  @ViewChild(ToasterComponent) toaster!: ToasterComponent;

  constructor(
    private camundaService: CamundaService,
    private fb: FormBuilder,
    private router: Router,
    private store: Store,
    public routerService: RouterService
  ) {}

  onSubmit() {
    this.mainForm.markAllAsTouched();
    if (this.mainForm.valid) {
      const key = this.clientEmail?.value ? this.clientEmail.value : '';
      this.setOnboarding({ clientEmail: key, taskIdEdit: '' });

      this.postCamundaStartProcess(
        Utils.buildStartProcessPayload(
          this.mainForm,
          this.clientAttachmentObject
        )
      );
    }
  }

  logIn() {
    this.routerService.login().subscribe(() => {
      if (this.routerService.isLoggedIn) {
        this.router.navigate(['/task-list'], {
          queryParamsHandling: 'preserve',
          preserveFragment: true,
        });
      }
    });
  }

  isInvalid(formControl: any) {
    console.log(!!Utils.isValidField(formControl));
    return Utils.isValidField(formControl);
  }

  public setOnboarding(state: Onboarding) {
    this.store.dispatch(setOnboarding(state));
  }

  postCamundaStartProcess(payloadStartProcess: CamundaPostStartProcessPayload) {
    this.camundaService.postStartProcess(payloadStartProcess).subscribe({
      next: () => {
        this.logIn();
      },
      error: (e: any) => {
        this.errorMessage(e.message || e.error.error);
      },
    });
  }

  handleInputFileChange(event: any) {
    this.clientAttachmentObject = this.clientAttachmentFormatter(event);
  }

  clientAttachmentFormatter = (event: any): void => {
    const reader = new FileReader();
    const files = event.target.files;
    if (files && files.length > 0) {
      const singleFile = files[0];
      reader.readAsDataURL(singleFile);
      reader.onload = () => {
        this.clientAttachmentObject = {
          value: reader.result ? reader.result?.toString().split(',')[1] : '',
          type: 'File',
          valueInfo: {
            filename: singleFile.name,
            mimeType: singleFile.type,
          },
        };
      };
    }
  };

  errorMessage(message: string) {
    this.addToast({
      title: 'Communication Error',
      delay: 5000,
      placement: ToasterPlacement.TopEnd,
      color: 'danger',
      autohide: true,
      message,
    });
  }

  addToast(options: any) {
    this.toaster.addToast(AppToastComponent, options);
  }

  get clientName() {
    return this.mainForm.get('clientName');
  }

  get clientCountry() {
    return this.mainForm.get('clientCountry');
  }

  get clientType() {
    return this.mainForm.get('clientType');
  }

  get clientEmail() {
    return this.mainForm.get('clientEmail');
  }

  get clientPhone() {
    return this.mainForm.get('clientPhone');
  }

  get clientAttachment() {
    return this.mainForm.get('clientAttachment');
  }

  get clientPassword() {
    return this.mainForm.get('clientPassword');
  }
}
