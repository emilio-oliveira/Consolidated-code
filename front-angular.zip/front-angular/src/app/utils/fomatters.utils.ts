import { FormBuilder, FormGroup } from '@angular/forms';
import {
  CamundaPostStartProcessPayload,
  ClientAttachment,
} from '../models/camunda.model';

export default class Utils {
  static buildStartProcessPayload(
    form: FormGroup,
    clientAttachmentObject: ClientAttachment
  ): CamundaPostStartProcessPayload {
    return {
      variables: {
        clientName: {
          value: form.get('clientName')?.value,
          type: 'String',
        },
        clientEmail: {
          value: form.get('clientEmail')?.value,
          type: 'String',
        },
        clientType: {
          value: form.get('clientType')?.value,
          type: 'String',
        },
        clientCountry: {
          value: form.get('clientCountry')?.value,
          type: 'String',
        },
        clientPhone: {
          value: form.get('clientPhone')?.value,
          type: 'String',
        },
        clientPassword: {
          value: form.get('clientPassword')?.value,
          type: 'String',
        },
        clientAttachment: {
          value: clientAttachmentObject.value,
          type: 'File',
          valueInfo: {
            filename: clientAttachmentObject.valueInfo.filename,
            mimeType: clientAttachmentObject.valueInfo.mimeType,
          },
        },
      },
      businessKey: form.get('clientEmail')?.value,
    };
  }

  static isValidField(formControl: any): boolean | undefined {
    return formControl?.touched && formControl?.invalid ? false : undefined;
  }
}
