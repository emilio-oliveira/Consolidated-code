export interface ProcessDefinition {
  id: string;
  name: string;
  key: string;
}

export interface CamundaTask {
  id: string;
  name: string;
  key: string;
}

export interface CamundaStartProcessLinks {
  method: string;
  href: string;
  rel: string;
}

export interface CamundaStartProcess {
  links: CamundaStartProcessLinks;
  id: string;
  definitionId: string;
  caseInstanceId?: string;
  ended: boolean;
  suspended: boolean;
  tenantId?: string;
}

export interface ValueType {
  value?: string;
  type: 'String';
}

export interface ClientAttachment {
  value: string;
  type: 'File';
  valueInfo: {
    filename: string;
    mimeType: string;
  };
}

export interface CamundaPostStartProcessPayload {
  variables: {
    clientName: ValueType;
    clientEmail: ValueType;
    clientType: ValueType;
    clientCountry: ValueType;
    clientPhone: ValueType;
    clientAttachment: ClientAttachment;
    clientPassword: ValueType;
  };
  businessKey: string;
}
