import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppToastComponent } from './toaster/toast.component';
import { ProgressModule, SharedModule, ToastModule } from '@coreui/angular';

@NgModule({
  declarations: [AppToastComponent],
  exports: [AppToastComponent, ToastModule],
  imports: [CommonModule, ToastModule, SharedModule, ProgressModule],
})
export class SharedComponentsModule {}
