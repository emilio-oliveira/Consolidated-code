package com.rbc.poc.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.spin.json.SpinJsonNode;
import org.springframework.stereotype.Component;

import static org.camunda.spin.Spin.JSON;

import org.json.JSONObject;

import java.util.HashMap;

@Component
    public class HashMap_to_JSON_Converter implements JavaDelegate {

    @Override
    public void execute(DelegateExecution delegateExecution) {

        JSONObject result = new JSONObject(HashMap.class.cast(delegateExecution.getVariable("transactionValidationList")));

        SpinJsonNode json = JSON(result.toString());

        delegateExecution.setVariable("transactionValidationJson", json);
    }
}
